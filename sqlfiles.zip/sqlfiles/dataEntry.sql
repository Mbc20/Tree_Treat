DELETE FROM BUYER;
DELETE FROM COMMERCIAL;
DELETE FROM COMMERCIAL_OWNER;
DELETE FROM COMMERCIAL_RECEIVER;
DELETE FROM GIFT;
DELETE FROM GIFT_OWNER;
DELETE FROM GIFT_RECEIVER;
DELETE FROM MARKET_HISTORY;
DELETE FROM PRODUCT;
DELETE FROM PRODUCT_IN_CART;
DELETE FROM SELLER;
DELETE FROM SELLER_LOCATION;

/*seller_location*/
INSERT INTO SELLER_LOCATION VALUES (1 ,'Rajshahi' ,'Bogra Sadar', 'Maltinogor', 'road no - 5');
INSERT INTO SELLER_LOCATION VALUES (2 ,'Rajshahi' ,'Bogra Sadar', 'Maltinogor', 'road no - 3');
INSERT INTO SELLER_LOCATION VALUES (3 ,'Rajshahi' ,'Bogra Sadar', 'Maltinogor', 'road no - 1');
INSERT INTO SELLER_LOCATION VALUES (4 ,'Dhaka' ,'Ramna', 'Polashi', 'road no - 10');
INSERT INTO SELLER_LOCATION VALUES (5 ,'Dinajpur' ,'Dinajpur Sadar', 'Motinogor', 'road no - 21');
INSERT INTO SELLER_LOCATION VALUES (6 ,'Pabna' ,'Pabna Sadar', 'Kalitola', 'road no - 13');
INSERT INTO SELLER_LOCATION VALUES (7 ,'Khulna' ,'Khulna Sadar', 'Mastarpara', 'road no - 11');
INSERT INTO SELLER_LOCATION VALUES (8 ,'Bogura' ,'Bogra Sadar', 'Uposhohor', 'road no - 17');
INSERT INTO SELLER_LOCATION VALUES (9 ,'Rajshahi' ,'Bagha', 'Courtpara', 'road no - 31');
INSERT INTO SELLER_LOCATION VALUES (10 ,'Dhaka' ,'Savar', 'Gopibag', 'road no - 18');
INSERT INTO SELLER_LOCATION VALUES (11 ,'Dhaka' ,'Gulshan', 'Banani', 'road no - 6');
INSERT INTO SELLER_LOCATION VALUES (12 ,'Chittagong' ,'Chittagong Sadar', 'Kazir Dewri', 'road no - 9');
INSERT INTO SELLER_LOCATION VALUES (13 ,'Khulna' ,'Jessore', 'Rajganj', 'road no - 4');
INSERT INTO SELLER_LOCATION VALUES (14 ,'Rajshahi' ,'Bogra Sadar', 'Shahidnagar', 'road no - 12');
INSERT INTO SELLER_LOCATION VALUES (15 ,'Comilla' ,'Comilla Sadar', 'Kandirpar', 'road no - 8');
INSERT INTO SELLER_LOCATION VALUES (16 ,'Sylhet' ,'Sylhet Sadar', 'Shibganj', 'road no - 7');
INSERT INTO SELLER_LOCATION VALUES (17 ,'Dhaka' ,'Mirpur', 'Pallabi', 'road no - 2');
INSERT INTO SELLER_LOCATION VALUES (18 ,'Rangpur' ,'Rangpur Sadar', 'Boro Bazar', 'road no - 14');
INSERT INTO SELLER_LOCATION VALUES (19 ,'Khulna' ,'Khulna Sadar', 'Sonadanga', 'road no - 19');
INSERT INTO SELLER_LOCATION VALUES (20 ,'Dhaka' ,'Dhanmondi', 'Sukrabad', 'road no - 22');
INSERT INTO SELLER_LOCATION VALUES (21 ,'Barisal' ,'Barisal Sadar', 'Natun Bazar', 'road no - 25');
INSERT INTO SELLER_LOCATION VALUES (22 ,'Sylhet' ,'Sylhet Sadar', 'Airport Road', 'road no - 15');
INSERT INTO SELLER_LOCATION VALUES (23 ,'Chittagong' ,'Chittagong Sadar', 'Agrabad', 'road no - 27');
INSERT INTO SELLER_LOCATION VALUES (24 ,'Dhaka' ,'Uttara', 'Sector 11', 'road no - 30');
INSERT INTO SELLER_LOCATION VALUES (25 ,'Rangpur' ,'Rangpur Sadar', 'Station Road', 'road no - 23');
INSERT INTO SELLER_LOCATION VALUES (26 ,'Khulna' ,'Jessore', 'Jhikorgachha', 'road no - 33');
INSERT INTO SELLER_LOCATION VALUES (27 ,'Dhaka' ,'Gazipur', 'Tongi', 'road no - 20');
INSERT INTO SELLER_LOCATION VALUES (28 ,'Rajshahi' ,'Bagha', 'Chandan Baari', 'road no - 28');
INSERT INTO SELLER_LOCATION VALUES (29 ,'Chittagong' ,'Feni', 'Khatunganj', 'road no - 29');
INSERT INTO SELLER_LOCATION VALUES (30 ,'Sylhet' ,'Sylhet Sadar', 'Tilagarh', 'road no - 32');
INSERT INTO SELLER_LOCATION VALUES (31 ,'Dhaka' ,'Banani', 'Kakoli', 'road no - 26');
INSERT INTO SELLER_LOCATION VALUES (32 ,'Rajshahi' ,'Bogra Sadar', 'Serniabad', 'road no - 24');
INSERT INTO SELLER_LOCATION VALUES (33 ,'Comilla' ,'Comilla Sadar', 'Jhautola', 'road no - 21');
INSERT INTO SELLER_LOCATION VALUES (34 ,'Dinajpur' ,'Dinajpur Sadar', 'Nawabganj', 'road no - 31');
INSERT INTO SELLER_LOCATION VALUES (35 ,'Pabna' ,'Pabna Sadar', 'Sujanagar', 'road no - 37');
INSERT INTO SELLER_LOCATION VALUES (36 ,'Khulna' ,'Khulna Sadar', 'Doulatpur', 'road no - 40');
INSERT INTO SELLER_LOCATION VALUES (37 ,'Bogura' ,'Bogra Sadar', 'Kazla', 'road no - 42');
INSERT INTO SELLER_LOCATION VALUES (38 ,'Rajshahi' ,'Bagha', 'Amirabad', 'road no - 45');
INSERT INTO SELLER_LOCATION VALUES (39 ,'Dhaka' ,'Savar', 'Hemayetpur', 'road no - 48');
INSERT INTO SELLER_LOCATION VALUES (40 ,'Chittagong' ,'Chittagong Sadar', 'GEC Circle', 'road no - 50');




/*buyer*/
INSERT INTO BUYER VALUES (1,'Rita','rita22@gmail.com','ri25ta',01755692567);
INSERT INTO BUYER VALUES (2,'Adiba','sumon200@gmail.com','happy2me',01759637547);
INSERT INTO BUYER VALUES (3,'Maria','maria55@gmail.com','treeLove2',01725692423);
INSERT INTO BUYER VALUES (4,'Nuha','marzia25@gmail.com','mar2@',01955652558);
INSERT INTO BUYER VALUES (5,'Nahin','nahin2002@gmail.com','Nahin54',01557892437);
INSERT INTO BUYER VALUES (6,'Sadia','sadia85@gmail.com','sadia123',01845692748);
INSERT INTO BUYER VALUES (7,'Imran','imran75@gmail.com','imran007',01678952413);
INSERT INTO BUYER VALUES (8,'Farhana','farhana90@gmail.com','farhana22',01789653241);
INSERT INTO BUYER VALUES (9,'Tariq','tariq99@gmail.com','tariq786',01945682374);
INSERT INTO BUYER VALUES (10,'Sultana','sultana89@gmail.com','sultana55',01548976532);
INSERT INTO BUYER VALUES (11,'Rahim','rahim72@gmail.com','rahim999',01867894523);
INSERT INTO BUYER VALUES (12,'Ayesha','ayesha91@gmail.com','itsAyesha',01784562973);
INSERT INTO BUYER VALUES (13,'Kamal','kamal66@gmail.com','kamal22',01985634792);
INSERT INTO BUYER VALUES (14,'Shabnam','shabnam25porshi@gmail.com','sUmmeR',01674582369);
INSERT INTO BUYER VALUES (15,'mohima','mohima93@gmail.com','mohima786',01896542731);
INSERT INTO BUYER VALUES (16,'Nasir','nasir78@gmail.com','nasir007',01578493652);
INSERT INTO BUYER VALUES (17,'Subah','subah89@gmail.com','subahVibs',01784592673);
INSERT INTO BUYER VALUES (18,'Tanjim','tanjim92@gmail.com','tanjim123',01968735421);
INSERT INTO BUYER VALUES (19,'Faria','faria75@gmail.com','faria22',01674529873);
INSERT INTO BUYER VALUES (20,'Shahed','shahed85@gmail.com','shahed786',01896542761);
INSERT INTO BUYER VALUES (21,'Nadia','nadia97@gmail.com','nadia007',01578493684);
INSERT INTO BUYER VALUES (22,'Rafi','rafi88@gmail.com','rafi123',01784592692);
INSERT INTO BUYER VALUES (23,'Tamanna','tamanna89@gmail.com','tamanna555',01968735437);
INSERT INTO BUYER VALUES (24,'Reza','rezaul5678@gmail.com','reza22',01674529857);
INSERT INTO BUYER VALUES (25,'Mim','mim76@gmail.com','mim786',01896542749);
INSERT INTO BUYER VALUES (26,'Rashed','rashed86@gmail.com','rashed007',01578493676);
INSERT INTO BUYER VALUES (27,'Nashit','nashit95@gmail.com','nashit123',01784592684);
INSERT INTO BUYER VALUES (28,'Anika','anika89@gmail.com','cupC@ke',01968735426);
INSERT INTO BUYER VALUES (29,'Faisal','faisal94@gmail.com','MeFaisal',01674529864);
INSERT INTO BUYER VALUES (30,'Sabrina','itssabrina@gmail.com','sabr!na786',01896542758);
INSERT INTO BUYER VALUES (31,'Abdullah','abdullah77@gmail.com','abdullah007',01578493672);
INSERT INTO BUYER VALUES (32,'Nadia','nadia86@gmail.com','nadia123',01784592673);
INSERT INTO BUYER VALUES (33,'Tahsin','tahsin93@gmail.com','tahsin555',01968735423);
INSERT INTO BUYER VALUES (34, 'Shova', 'shova94@gmail.com', 'treelover', 01784592683);
INSERT INTO BUYER VALUES (35, 'Anuva', 'anuva87@gmail.com', 'anuvaWAR', 01968735429);
INSERT INTO BUYER VALUES (36, 'Arne', 'arne95@gmail.com', 'arne456', 01674529868);
INSERT INTO BUYER VALUES (37, 'Tuli', 'tuli88@gmail.com', 'tultuli', 01896542759);
INSERT INTO BUYER VALUES (38, 'Abir', 'abir91@gmail.com', 'abirMax', 01578493670);
INSERT INTO BUYER VALUES (39, 'Ayon', 'iftekherayon@gmail.com', 'ayon007', 01784592695);
INSERT INTO BUYER VALUES (40, 'Miraj', 'miraj64@gmail.com', 'mirajMultiple', 01968735434);
INSERT INTO BUYER VALUES (41, 'Zisan', 'zisan86@gmail.com', 'zisan22', 01674529861);
INSERT INTO BUYER VALUES (42, 'Fihad', 'fihad89@gmail.com', 'fihad786', 01896542754);
INSERT INTO BUYER VALUES (43, 'Masha', 'masha96@gmail.com', 'masha999', 01578493678);
INSERT INTO BUYER VALUES (44, 'Metaly', 'metaly87@gmail.com', 'louhometal', 01784592679);
INSERT INTO BUYER VALUES (45, 'Habiba', 'habiba94@gmail.com', 'habibi', 01968735440);




/*seller*/
INSERT INTO SELLER VALUES (1, 'Ritu', 'ritu2200@gmail.com', 'ri252ta', 01755692567, 1);
INSERT INTO SELLER VALUES (2, 'Oishi', 'oishi2005@gmail.com', 'treeMe11', 01747538235, 2);
INSERT INTO SELLER VALUES (3, 'Arpita', 'arpita2005@gmail.com', 'arpita@123', 01747538235, 6);
INSERT INTO SELLER VALUES (4, 'Swastika', 'swastika2005@gmail.com', 'sunny#456', 01747538235, 9);
INSERT INTO SELLER VALUES (5, 'Saba', 'saba2005@gmail.com', 'sabatre22e', 01747538235, 10);
INSERT INTO SELLER VALUES (6, 'Farid', 'faridulalom@gmail.com', 'farid123', 01712345678, 3);
INSERT INTO SELLER VALUES (7, 'Nadia', 'nadia@gmail.com', 'nadia456', 01723456789, 4);
INSERT INTO SELLER VALUES (8, 'Tariq', 'tariq@gmail.com', 'tariq789', 01734567890, 11);
INSERT INTO SELLER VALUES (9, 'Sadia', 'sadiamoni21@gmail.com', 'sadi101', 01745678901, 15);
INSERT INTO SELLER VALUES (10, 'Munir', 'munir@gmail.com', 'munir22', 01756789012, 8);
INSERT INTO SELLER VALUES (11, 'Nusrat', 'nusratjahan@gmail.com', 'nusrat99', 01767890123, 22);
INSERT INTO SELLER VALUES (12, 'Imran', 'imranhaque@gmail.com', 'imran777', 01778901234, 13);
INSERT INTO SELLER VALUES (13, 'Sultana', 'sultana@gmail.com', 'sultana88', 01789012345, 20);
INSERT INTO SELLER VALUES (14, 'Rahman', 'rahman@gmail.com', 'rahman2022', 01790123456, 7);
INSERT INTO SELLER VALUES (15, 'Sonia', 'sonia@gmail.com', 'sonia321', 01701234567, 14);
INSERT INTO SELLER VALUES (16, 'Asif', 'asif@gmail.com', 'asif654', 01711234568, 24);
INSERT INTO SELLER VALUES (17, 'Fariha', 'fariha@gmail.com', 'summer2023', 01721234569, 16);
INSERT INTO SELLER VALUES (18, 'Rahim', 'rahim@gmail.com', 'p@ssw0rd', 01731234570, 17);
INSERT INTO SELLER VALUES (19, 'Nadia', 'nadia22@gmail.com', 'nadia2211', 01741234571, 18);
INSERT INTO SELLER VALUES (20, 'Sakib', 'sakib@gmail.com', 'sakib1337', 01751234572, 19);
INSERT INTO SELLER VALUES (21, 'Ruponty', 'ruponty33das@gmail.com', 'rups555', 01761234573, 21);
INSERT INTO SELLER VALUES (22, 'Moushumi', 'moushumi@gmail.com', 'moonLight', 01771234574, 23);
INSERT INTO SELLER VALUES (23, 'Rahat', 'rahat@gmail.com', 'r@hat987', 01781234575, 25);
INSERT INTO SELLER VALUES (24, 'Nashit', 'nashit@gmail.com', 'nashitLove', 01791234576, 27);
INSERT INTO SELLER VALUES (25, 'Farah', 'farah@gmail.com', 'farah100', 01701234567, 29);
INSERT INTO SELLER VALUES (26, 'Nahid', 'nahid@gmail.com', 'nahid654', 01711234568, 31);
INSERT INTO SELLER VALUES (27, 'Fariha', 'fariha61@gmail.com', 'fariha123', 01721234569, 33);
INSERT INTO SELLER VALUES (28, 'Raihan', 'raihan@gmail.com', 'raihan007', 01731234570, 35);
INSERT INTO SELLER VALUES (29, 'Tanjim', 'tanjim@gmail.com', 'tanjim22', 01741234571, 37);
INSERT INTO SELLER VALUES (30, 'Sakib', 'sakib88@gmail.com', 'sakib1337', 01751234572, 39);
INSERT INTO SELLER VALUES (31, 'Promi', 'promi@gmail.com', 'P@ssw0rd1', 01711234568, 32);
INSERT INTO SELLER VALUES (32, 'Fahmida', 'fahmida@gmail.com', 'eka_ami', 01721234569, 33);
INSERT INTO SELLER VALUES (33, 'Momo', 'momo@gmail.com', 'M0m0!789', 01731234570, 34);
INSERT INTO SELLER VALUES (34, 'Mumu', 'mumu@gmail.com', 'MuM1234', 01741234571, 35);
INSERT INTO SELLER VALUES (35, 'Maisha', 'maisha@gmail.com', 'Maisha22', 01751234572, 36);
INSERT INTO SELLER VALUES (36, 'Adil', 'adil@gmail.com', 'adil2023', 01761234573, 37);
INSERT INTO SELLER VALUES (37, 'Irtiaz', 'irtiaz@gmail.com', '1rt!az123', 01771234574, 38);
INSERT INTO SELLER VALUES (38, 'Rakesh', 'rakesh117@gmail.com', 'Raaaakeshhhh', 01781234575, 39);
INSERT INTO SELLER VALUES (39, 'Aoishy', 'aoishy@gmail.com', 'aoishy789', 01791234576, 40);
INSERT INTO SELLER VALUES (40, 'Sithi', 'sithi2001@gmail.com', 'lifePerahin', 01712345678, 1);
INSERT INTO SELLER VALUES (41, 'Kabbo', 'kabbosorup@gmail.com', 'K@bbo22', 01723456789, 2);
INSERT INTO SELLER VALUES (42, 'Silma', 'silmasubah2001@gmail.com', 'S!lma123', 01734567890, 3);
INSERT INTO SELLER VALUES (43, 'Pranti', 'prettypranti21@gmail.com', 'Pr@ntiii', 01745678901, 4);
INSERT INTO SELLER VALUES (44, 'Saifa', 'saifaafri@gmail.com', 'S@1fa!!!22', 01756789012, 5);
INSERT INTO SELLER VALUES (45, 'Mahin', 'mahin@gmail.com', 'M@hin789', 01767890123, 6);





INSERT INTO PRODUCT VALUES (1, 'Rose',10 ,'Plant');
INSERT INTO PRODUCT VALUES (2, 'Sunflower',10 ,'Plant');
INSERT INTO PRODUCT VALUES (3, 'Sunflower',20 ,'Seed');
INSERT INTO PRODUCT VALUES (4, 'Marigold',25 ,'Plant');
INSERT INTO PRODUCT VALUES (5, 'Orange',15 ,'Plant');

INSERT INTO GIFT VALUES (1);
INSERT INTO GIFT VALUES (3);

INSERT INTO COMMERCIAL VALUES (2 , 100);
INSERT INTO COMMERCIAL VALUES (5 , 300);
INSERT INTO COMMERCIAL VALUES (4 , 50);

INSERT INTO COMMERCIAL_OWNER VALUES (1 , 5);
INSERT INTO COMMERCIAL_OWNER VALUES (2 , 2);
INSERT INTO COMMERCIAL_OWNER VALUES (4 , 4);

INSERT INTO COMMERCIAL_RECEIVER VALUES (2 , 4);
INSERT INTO COMMERCIAL_RECEIVER VALUES (1 , 2);
INSERT INTO COMMERCIAL_RECEIVER VALUES (3 , 5);

INSERT INTO GIFT_OWNER VALUES (1 , 1);
INSERT INTO GIFT_OWNER VALUES (5 , 3);

INSERT INTO GIFT_RECEIVER VALUES (2 , 1);
INSERT INTO GIFT_RECEIVER VALUES (4 , 3);

INSERT INTO MARKET_HISTORY VALUES (1 , 1 ,3 ,5 , 2, SYSDATE);
INSERT INTO MARKET_HISTORY VALUES (2 , 2 ,1 ,2 , 2, SYSDATE);
INSERT INTO MARKET_HISTORY VALUES (3 , 4 ,2 ,4 , 2, SYSDATE);
INSERT INTO MARKET_HISTORY VALUES (4 , 1 ,2 ,1 , 2, SYSDATE);
INSERT INTO MARKET_HISTORY VALUES (5 , 5 ,4 ,3 , 2, SYSDATE);

INSERT INTO PRODUCT_IN_CART VALUES (2 , 4, 2, 50);