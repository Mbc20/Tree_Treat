const nam=document.getElementById('name');
const emai=document.getElementById('email');
const contac=document.getElementById('contact');
const distric=document.getElementById('district');
const than=document.getElementById('thana');
const are=document.getElementById('area');
const detail=document.getElementById('details');


async function sellerProfile(){

  const str=`${localStorage.getItem('sellerEmail')}_${localStorage.getItem('sellerPassword')}`;

  const response= await fetch(`/sellerProfile/${str}`);
  const data = await response.json();

  nam.textContent=`${data[0][0]}`;
  emai.textContent=`${data[0][1]}`;
  contac.textContent=`${data[0][2]}`;
  distric.textContent=`${data[0][3]}`;
  than.textContent=`${data[0][4]}`;
  are.textContent=`${data[0][5]}`;
  detail.textContent=`${data[0][6]}`;
}


window.onload = function() {
  sellerProfile();
};