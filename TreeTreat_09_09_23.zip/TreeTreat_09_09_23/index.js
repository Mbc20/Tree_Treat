const oracledb = require('oracledb');

const express=require('express')
const app=express()
const port=4000

app.use(express.static('public'));

app.listen(port);

async function runQuery(query) {
    const connection = await oracledb.getConnection({
        user:'TREETREAT',
        password:'tt',
        connectString:'localhost/orclpdb',
    });

     const result = await connection.execute(query);

    await connection.close();

    return result;
}

async function runQuery(query, bindParams = {}) {
  const connection = await oracledb.getConnection({
    user: 'TREETREAT',
    password: 'tt',
    connectString: 'localhost/orclpdb',
  });

  const result = await connection.execute(query, bindParams);

  await connection.close();
  return result;
}

app.get('/buyerSignIn/:em', async (req, res) => {
    const em=req.params.em;
    const data=await runQuery(
        `SELECT * FROM BUYER WHERE EMAIL='${em}'`
    );

    res.send(data.rows);
  })

app.get('/sellerSignIn/:em', async (req, res) => {
    const em=req.params.em;
    const data=await runQuery(
        `SELECT * FROM SELLER WHERE EMAIL='${em}'`
    );

    res.send(data.rows);
  })  

app.get('/buyerSignUp/:info', async (req, res) => {
    const info=req.params.info;
    const parts = info.split('_');

    //console.log(parts);

    const data=await runQuery(
      `DECLARE
      C NUMBER;
      BEGIN
      SELECT MAX(BUYER_ID) INTO C FROM BUYER;
      C:=C+1;
      INSERT INTO BUYER (BUYER_ID, NAME, EMAIL, PASSWORD, CONTACT) VALUES (C,:NAME,:EMAIL,:PASSWORD,:CONTACT);
      COMMIT;
      END;`,{
        NAME: parts[0],
        EMAIL: parts[1],
        PASSWORD: parts[2],
        CONTACT: parts[3]
      }
    );

    res.send(data.rows);
  })


  app.get('/sellerSignUp/:info', async (req, res) => {
    const info = req.params.info;
    const parts = info.split('_');

    //console.log(parts);

    const check = await runQuery(
        `SELECT * FROM SELLER_LOCATION 
        WHERE UPPER(DISTRICT)=UPPER(:DISTRICT) AND UPPER(THANA)=UPPER(:THANA) AND UPPER(AREA)=UPPER(:AREA) AND UPPER(DETAILS)=UPPER(:DETAILS)`, {
            DISTRICT: parts[4],
            THANA: parts[5],
            AREA: parts[6],
            DETAILS: parts[7]
        }
    );

    if (check.rows.length === 0) { // NEW LOCATION
      //console.log('here');
        const data2 = await runQuery(
            `DECLARE
              D NUMBER;
            BEGIN
              SELECT MAX(LOCATION_ID) INTO D FROM SELLER_LOCATION;
              D := D + 1;
              INSERT INTO SELLER_LOCATION (LOCATION_ID, DISTRICT, THANA, AREA, DETAILS)
              VALUES (D, :DISTRICT, :THANA, :AREA, :DETAILS);
              COMMIT;
            END;`, {
                DISTRICT: parts[4],
                THANA: parts[5],
                AREA: parts[6],
                DETAILS: parts[7]
            }
        );
    }

    const data = await runQuery(
        `DECLARE
          LL NUMBER;
          CC NUMBER;
        BEGIN
          SELECT LOCATION_ID INTO LL FROM SELLER_LOCATION 
          WHERE UPPER(DISTRICT) = UPPER(:DISTRICT)
            AND UPPER(THANA) = UPPER(:THANA)
            AND UPPER(AREA) = UPPER(:AREA)
            AND UPPER(DETAILS) = UPPER(:DETAILS);

          SELECT MAX(SELLER_ID) INTO CC FROM SELLER;
          CC := CC + 1;

          INSERT INTO SELLER (SELLER_ID, NAME, EMAIL, PASSWORD, CONTACT, LOCATION_ID)
          VALUES (CC, :NAME, :EMAIL, :PASSWORD, :CONTACT, LL);
          COMMIT;
        END;`, {
            NAME: parts[0],
            EMAIL: parts[1],
            PASSWORD: parts[2],
            CONTACT: parts[3],
            DISTRICT: parts[4],
            THANA: parts[5],
            AREA: parts[6],
            DETAILS: parts[7]
        }
    );

    res.send(data.rows);
});

app.get('/buyerProfile/:info', async (req, res) => {
  const info = req.params.info;
  const parts = info.split('_');

  const data = await runQuery(
        `SELECT * FROM BUYER 
        WHERE EMAIL=:EMAIL AND PASSWORD=:PASSWORD`, {
            EMAIL: parts[0],
            PASSWORD: parts[1]
        }
    );
  //console.log(data.rows);
  res.send(data.rows);
})  

app.get('/sellerProfile/:info', async (req, res) => {
  const info = req.params.info;
  const parts = info.split('_');

  const data = await runQuery(
        `SELECT S.NAME, S.EMAIL, S.CONTACT, L.DISTRICT, L.THANA, L.AREA, L.DETAILS 
        FROM SELLER S JOIN SELLER_LOCATION L ON (S.LOCATION_ID=L.LOCATION_ID) 
        WHERE S.EMAIL=:EMAIL AND S.PASSWORD=:PASSWORD`, {
            EMAIL: parts[0],
            PASSWORD: parts[1]
        }
    );
  res.send(data.rows);
})  



app.get('/product/allcommercialplant', async (req, res) => {
  
  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME, P.AVAILABLE_QUANTITY, C.PRICE
        FROM PRODUCT P JOIN COMMERCIAL C ON (P.PRODUCT_ID=C.PRODUCT_ID)
        WHERE P.CATEGORY='plant'`
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 


app.get('/product/allgiftplant', async (req, res) => {
  
  const data = await runQuery(
        `SELECT P.PRODUCT_NAME, P.AVAILABLE_QUANTITY
        FROM PRODUCT P JOIN GIFT G ON (P.PRODUCT_ID=G.PRODUCT_ID)
        WHERE P.CATEGORY='plant'`
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 


app.get('/searchgiftplant/:word', async (req, res) => {
  const info = req.params.word;
  const parts = info.split(' ');

  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME ,P.AVAILABLE_QUANTITY
        FROM PRODUCT P JOIN GIFT G
        ON P.PRODUCT_ID = G.PRODUCT_ID
        WHERE P.CATEGORY = 'plant' AND INSTR(UPPER(P.PRODUCT_NAME),UPPER(:key))>0`,{
          key:parts[0]
        }
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 


app.get('/searchcommercialplant/:word', async (req, res) => {
  const info = req.params.word;
  const parts = info.split(' ');

  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME, P.AVAILABLE_QUANTITY, C.PRICE
        FROM PRODUCT P JOIN COMMERCIAL C
        ON P.PRODUCT_ID = C.PRODUCT_ID
        WHERE P.CATEGORY ='plant' AND INSTR(UPPER(P.PRODUCT_NAME),UPPER(:key))>0`,{
          key:parts[0]
        }
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 


app.get('/product/allcommercialseed', async (req, res) => {
  
  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME, P.AVAILABLE_QUANTITY, C.PRICE
        FROM PRODUCT P JOIN COMMERCIAL C ON (P.PRODUCT_ID=C.PRODUCT_ID)
        WHERE P.CATEGORY='seed'`
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 

app.get('/searchcommercialseed/:word', async (req, res) => {
  const info = req.params.word;
  const parts = info.split(' ');

  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME, P.AVAILABLE_QUANTITY, C.PRICE
        FROM PRODUCT P JOIN COMMERCIAL C
        ON P.PRODUCT_ID = C.PRODUCT_ID
        WHERE P.CATEGORY ='seed' AND INSTR(UPPER(P.PRODUCT_NAME),UPPER(:key))>0`,{
          key:parts[0]
        }
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 

app.get('/product/allgiftseed', async (req, res) => {
  
  const data = await runQuery(
        `SELECT P.PRODUCT_NAME, P.AVAILABLE_QUANTITY
        FROM PRODUCT P JOIN GIFT G ON (P.PRODUCT_ID=G.PRODUCT_ID)
        WHERE P.CATEGORY='seed'`
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 


app.get('/searchgiftseed/:word', async (req, res) => {
  const info = req.params.word;
  const parts = info.split(' ');

  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME ,P.AVAILABLE_QUANTITY
        FROM PRODUCT P JOIN GIFT G
        ON P.PRODUCT_ID = G.PRODUCT_ID
        WHERE P.CATEGORY = 'seed' AND INSTR(UPPER(P.PRODUCT_NAME),UPPER(:key))>0`,{
          key:parts[0]
        }
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 


app.get('/product/allcommercialaccessories', async (req, res) => {
  
  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME, P.AVAILABLE_QUANTITY, C.PRICE
        FROM PRODUCT P JOIN COMMERCIAL C ON (P.PRODUCT_ID=C.PRODUCT_ID)
        WHERE P.CATEGORY='accessories'`
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 

app.get('/searchcommercialaccessories/:word', async (req, res) => {
  const info = req.params.word;
  const parts = info.split(' ');

  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME, P.AVAILABLE_QUANTITY, C.PRICE
        FROM PRODUCT P JOIN COMMERCIAL C
        ON P.PRODUCT_ID = C.PRODUCT_ID
        WHERE P.CATEGORY ='accessories' AND INSTR(UPPER(P.PRODUCT_NAME),UPPER(:key))>0`,{
          key:parts[0]
        }
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 

app.get('/product/allgiftaccessories', async (req, res) => {
  
  const data = await runQuery(
        `SELECT P.PRODUCT_NAME, P.AVAILABLE_QUANTITY
        FROM PRODUCT P JOIN GIFT G ON (P.PRODUCT_ID=G.PRODUCT_ID)
        WHERE P.CATEGORY='accessories'`
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 


app.get('/searchgiftaccessories/:word', async (req, res) => {
  const info = req.params.word;
  const parts = info.split(' ');

  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME ,P.AVAILABLE_QUANTITY
        FROM PRODUCT P JOIN GIFT G
        ON P.PRODUCT_ID = G.PRODUCT_ID
        WHERE P.CATEGORY = 'accessories' AND INSTR(UPPER(P.PRODUCT_NAME),UPPER(:key))>0`,{
          key:parts[0]
        }
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 