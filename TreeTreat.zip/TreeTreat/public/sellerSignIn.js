const email=document.getElementById('email');
const password=document.getElementById('password');
const confirmText=document.getElementById('text');

async function sellerSignIn(){
  const em=email.value;
  const pass=password.value;
  
  const response= await fetch(`/sellerSignIn/${em}`);
  const data = await response.json();
  //console.log(id);
  console.log(data);

  if(`${data[0][3]}`==`${pass}`){
    confirmText.textContent=`Login successful!`;
    console.log(confirmText);
  }
  else{
    confirmText.textContent=`Wrong email/password :( Try again...`;
    console.log(confirmText);
  }
}
