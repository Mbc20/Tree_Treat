const email=document.getElementById('email');
const password=document.getElementById('password');
const confirmText=document.getElementById('text');

async function login(){
  const em=email.value;
  const pass=password.value;
  
  const response= await fetch(`/seller/${em}`);
  const data = await response.json();
  //console.log(id);
  console.log(data);

  if(`${data[0][3]}`==`${pass}`){
    confirmText.textContent=`Login successful!`;
  }
  else{
    confirmText.textContent=`Wrong email/password :( Try again...`;
  }
}
