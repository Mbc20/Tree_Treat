const nm=document.getElementById('name');
const email=document.getElementById('email');
const password=document.getElementById('password');
const contact=document.getElementById('contact');
const dist=document.getElementById('district');
const thn=document.getElementById('thana');
const ar=document.getElementById('area');
const det=document.getElementById('details');

//const confirmText=document.getElementById('text');

async function sellerSignUp(){
  const n=nm.value;
  const em=email.value;
  const pass=password.value;
  const cont=contact.value;    
  const district=dist.value;
  const thana=thn.value;
  const area=ar.value;
  const details=det.value;    

  const str=`${n}_${em}_${pass}_${cont}_${district}_${thana}_${area}_${details}`;

  const response= await fetch(`/sellerSignUp/${str}`);
  //const data = await response.json();
  //console.log(id);
  //console.log(data);

  //confirmText.textContent=`signup successful!`;

  // if(`${data[0][3]}`==`${pass}`){
  //   confirmText.textContent=`Login successful!`;
  // }
  // else{
  //   confirmText.textContent=`Wrong email/password :( Try again...`;
  // }
}
