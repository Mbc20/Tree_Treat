const oracledb = require('oracledb');

const express=require('express')
const app=express()
const port=5000

app.use(express.static('public'));

app.listen(port);

async function runQuery(query) {
    const connection = await oracledb.getConnection({
        user:'TREETREAT',
        password:'tt',
        connectString:'localhost/orclpdb',
    });

     const result = connection.execute(query);

    await connection.close();

    return result;
}

async function runQuery(query, bindParams = {}) {
  const connection = await oracledb.getConnection({
    user: 'TREETREAT',
    password: 'tt',
    connectString: 'localhost/orclpdb',
  });

  const result = await connection.execute(query, bindParams);

  await connection.close();
  return result;
}

app.get('/buyerSignIn/:em', async (req, res) => {
    const em=req.params.em;
    const data=await runQuery(
        `SELECT * FROM BUYER WHERE EMAIL='${em}'`
    );

    res.send(data.rows);
  })

app.get('/sellerSignIn/:em', async (req, res) => {
    const em=req.params.em;
    const data=await runQuery(
        `SELECT * FROM SELLER WHERE EMAIL='${em}'`
    );

    res.send(data.rows);
  })  

app.get('/buyerSignUp/:info', async (req, res) => {
    const info=req.params.info;
    const parts = info.split('_');

    console.log(parts);

    const data=await runQuery(
      `DECLARE
      C NUMBER;
      BEGIN
      SELECT COUNT(*) INTO C FROM BUYER;
      C:=C+1;
      INSERT INTO BUYER (BUYER_ID, NAME, EMAIL, PASSWORD, CONTACT) VALUES (C,:NAME,:EMAIL,:PASSWORD,:CONTACT);
      COMMIT;
      END;`,{
        NAME: parts[0],
        EMAIL: parts[1],
        PASSWORD: parts[2],
        CONTACT: parts[3]
      }
    );

    res.send(data.rows);
  })


app.get('/sellerSignUp/:info', async (req, res) => {
    const info=req.params.info;
    const parts = info.split('_');

    console.log(parts);

    const check=await runQuery(
      `SELECT * FROM SELLER_LOCATION 
      DISTRICT='${parts[4]}' AND THANA='${parts[5]}' AND AREA='${parts[6]}' AND DETAILS='${parts[7]}';`
    );

    if(check!=null){
      
    }

    const data=await runQuery(
      `DECLARE
      C NUMBER;
      BEGIN
      SELECT COUNT(*) INTO C FROM BUYER;
      C:=C+1;
      INSERT INTO BUYER (BUYER_ID, NAME, EMAIL, PASSWORD, CONTACT) VALUES (C,:NAME,:EMAIL,:PASSWORD,:CONTACT);
      COMMIT;
      END;`,{
        NAME: parts[0],
        EMAIL: parts[1],
        PASSWORD: parts[2],
        CONTACT: parts[3]
      }
    );

    res.send(data.rows);
  })  