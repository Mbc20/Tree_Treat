const oracledb = require('oracledb');

const express=require('express')
const app=express()
const port=5000

app.use(express.static('public'));

app.listen(port);

async function runQuery(query) {
    const connection = await oracledb.getConnection({
        user:'TREETREAT',
        password:'tt',
        connectString:'localhost/orclpdb',
    });

     const result = connection.execute(query);

    await connection.close();

    return result;
}

app.get('/seller/:em', async (req, res) => {
    const em=req.params.em;
    const data=await runQuery(
        `SELECT * FROM SELLER WHERE EMAIL='${em}'`
    );

    res.send(data.rows);
  })

