const oracledb = require('oracledb');

const express=require('express')
const app=express()
const port=5000

app.use(express.static('public'));

app.listen(port);

async function runQuery(query) {
    const connection = await oracledb.getConnection({
        user:'TREETREAT',
        password:'tt',
        connectString:'localhost/orclpdb',
    });

     const result = connection.execute(query);

    await connection.close();

    return result;
}

async function runQuery(query, bindParams = {}) {
  const connection = await oracledb.getConnection({
    user: 'TREETREAT',
    password: 'tt',
    connectString: 'localhost/orclpdb',
  });

  const result = await connection.execute(query, bindParams);

  await connection.close();
  return result;
}

app.get('/buyerSignIn/:em', async (req, res) => {
    const em=req.params.em;
    const data=await runQuery(
        `SELECT * FROM BUYER WHERE EMAIL='${em}'`
    );

    res.send(data.rows);
  })

app.get('/sellerSignIn/:em', async (req, res) => {
    const em=req.params.em;
    const data=await runQuery(
        `SELECT * FROM SELLER WHERE EMAIL='${em}'`
    );

    res.send(data.rows);
  })  

app.get('/buyerSignUp/:info', async (req, res) => {
    const info=req.params.info;
    const parts = info.split('_');

    //console.log(parts);

    const data=await runQuery(
      `DECLARE
      C NUMBER;
      BEGIN
      SELECT COUNT(*) INTO C FROM BUYER;
      C:=C+1;
      INSERT INTO BUYER (BUYER_ID, NAME, EMAIL, PASSWORD, CONTACT) VALUES (C,:NAME,:EMAIL,:PASSWORD,:CONTACT);
      COMMIT;
      END;`,{
        NAME: parts[0],
        EMAIL: parts[1],
        PASSWORD: parts[2],
        CONTACT: parts[3]
      }
    );

    res.send(data.rows);
  })


  app.get('/sellerSignUp/:info', async (req, res) => {
    const info = req.params.info;
    const parts = info.split('_');

    console.log(parts);

    const check = await runQuery(
        `SELECT * FROM SELLER_LOCATION 
        WHERE DISTRICT=:DISTRICT AND THANA=:THANA AND AREA=:AREA AND DETAILS=:DETAILS`, {
            DISTRICT: parts[4],
            THANA: parts[5],
            AREA: parts[6],
            DETAILS: parts[7]
        }
    );

    if (check.rows.length === 0) { // NEW LOCATION
      //console.log('here');
        const data2 = await runQuery(
            `DECLARE
              D NUMBER;
            BEGIN
              SELECT COUNT(*) INTO D FROM SELLER_LOCATION;
              D := D + 1;
              INSERT INTO SELLER_LOCATION (LOCATION_ID, DISTRICT, THANA, AREA, DETAILS)
              VALUES (D, :DISTRICT, :THANA, :AREA, :DETAILS);
              COMMIT;
            END;`, {
                DISTRICT: parts[4],
                THANA: parts[5],
                AREA: parts[6],
                DETAILS: parts[7]
            }
        );
    }

    const data = await runQuery(
        `DECLARE
          LL NUMBER;
          CC NUMBER;
        BEGIN
          SELECT LOCATION_ID INTO LL FROM SELLER_LOCATION 
          WHERE UPPER(DISTRICT) = UPPER(:DISTRICT)
            AND UPPER(THANA) = UPPER(:THANA)
            AND UPPER(AREA) = UPPER(:AREA)
            AND UPPER(DETAILS) = UPPER(:DETAILS);

          SELECT COUNT(*) INTO CC FROM BUYER;
          CC := CC + 1;

          INSERT INTO SELLER (SELLER_ID, NAME, EMAIL, PASSWORD, CONTACT, LOCATION_ID)
          VALUES (CC, :NAME, :EMAIL, :PASSWORD, :CONTACT, LL);
          COMMIT;
        END;`, {
            NAME: parts[0],
            EMAIL: parts[1],
            PASSWORD: parts[2],
            CONTACT: parts[3],
            DISTRICT: parts[4],
            THANA: parts[5],
            AREA: parts[6],
            DETAILS: parts[7]
        }
    );

    res.send(data.rows);
});








  // INSERT INTO SELLER_LOCATION (LOCATION_ID, DISTRICT, THANA, AREA, DETAILS) VALUES (L,:DISTRICT,:THANA,:AREA,:DETAILS);
  //       COMMIT;
  //       END;`,{
  //         DISTRICT: parts[4],
  //         THANA: parts[5],
  //         AREA: parts[6],
  //         DETAILS: parts[7]
  //       }