const oracledb = require('oracledb');

const express=require('express')
const app=express()
const port=4000

app.use(express.static('public'));

app.listen(port);

async function runQuery(query) {
    const connection = await oracledb.getConnection({
        user:'TREETREAT',
        password:'tt',
        connectString:'localhost/orclpdb',
    });

     const result = await connection.execute(query);

    await connection.close();

    return result;
}

async function runQuery(query, bindParams = {}) {
  const connection = await oracledb.getConnection({
    user: 'TREETREAT',
    password: 'tt',
    connectString: 'localhost/orclpdb',
  });

  const result = await connection.execute(query, bindParams);

  await connection.close();
  return result;
}

app.get('/buyerSignIn/:em', async (req, res) => {
    const em=req.params.em;
    const data=await runQuery(
        `SELECT * FROM BUYER WHERE EMAIL='${em}'`
    );

    res.send(data.rows);
  })

app.get('/sellerSignIn/:em', async (req, res) => {
    const em=req.params.em;
    const data=await runQuery(
        `SELECT * FROM SELLER WHERE EMAIL='${em}'`
    );

    res.send(data.rows);
  })  

app.get('/buyerSignUp/:info', async (req, res) => {
    const info=req.params.info;
    const parts = info.split('_');

    //console.log(parts);

    const data=await runQuery(
      `DECLARE
      C NUMBER;
      BEGIN
      SELECT MAX(BUYER_ID) INTO C FROM BUYER;
      C:=C+1;
      INSERT INTO BUYER (BUYER_ID, NAME, EMAIL, PASSWORD, CONTACT) VALUES (C,:NAME,:EMAIL,:PASSWORD,:CONTACT);
      COMMIT;
      END;`,{
        NAME: parts[0],
        EMAIL: parts[1],
        PASSWORD: parts[2],
        CONTACT: parts[3]
      }
    );

    res.send(data.rows);
  })


  app.get('/sellerSignUp/:info', async (req, res) => {
    const info = req.params.info;
    const parts = info.split('_');

    //console.log(parts);

    const check = await runQuery(
        `SELECT * FROM SELLER_LOCATION 
        WHERE UPPER(DISTRICT)=UPPER(:DISTRICT) AND UPPER(THANA)=UPPER(:THANA) AND UPPER(AREA)=UPPER(:AREA) AND UPPER(DETAILS)=UPPER(:DETAILS)`, {
            DISTRICT: parts[4],
            THANA: parts[5],
            AREA: parts[6],
            DETAILS: parts[7]
        }
    );

    if (check.rows.length === 0) { // NEW LOCATION
      //console.log('here');
        const data2 = await runQuery(
            `DECLARE
              D NUMBER;
            BEGIN
              SELECT MAX(LOCATION_ID) INTO D FROM SELLER_LOCATION;
              D := D + 1;
              INSERT INTO SELLER_LOCATION (LOCATION_ID, DISTRICT, THANA, AREA, DETAILS)
              VALUES (D, :DISTRICT, :THANA, :AREA, :DETAILS);
              COMMIT;
            END;`, {
                DISTRICT: parts[4],
                THANA: parts[5],
                AREA: parts[6],
                DETAILS: parts[7]
            }
        );
    }

    const data = await runQuery(
        `DECLARE
          LL NUMBER;
          CC NUMBER;
        BEGIN
          SELECT LOCATION_ID INTO LL FROM SELLER_LOCATION 
          WHERE UPPER(DISTRICT) = UPPER(:DISTRICT)
            AND UPPER(THANA) = UPPER(:THANA)
            AND UPPER(AREA) = UPPER(:AREA)
            AND UPPER(DETAILS) = UPPER(:DETAILS);

          SELECT MAX(SELLER_ID) INTO CC FROM SELLER;
          CC := CC + 1;

          INSERT INTO SELLER (SELLER_ID, NAME, EMAIL, PASSWORD, CONTACT, LOCATION_ID)
          VALUES (CC, :NAME, :EMAIL, :PASSWORD, :CONTACT, LL);
          COMMIT;
        END;`, {
            NAME: parts[0],
            EMAIL: parts[1],
            PASSWORD: parts[2],
            CONTACT: parts[3],
            DISTRICT: parts[4],
            THANA: parts[5],
            AREA: parts[6],
            DETAILS: parts[7]
        }
    );

    res.send(data.rows);
});

app.get('/buyerProfile/:info', async (req, res) => {
  const info = req.params.info;
  const parts = info.split('_');

  const data = await runQuery(
        `SELECT * FROM BUYER 
        WHERE EMAIL=:EMAIL AND PASSWORD=:PASSWORD`, {
            EMAIL: parts[0],
            PASSWORD: parts[1]
        }
    );
  //console.log(data.rows);
  res.send(data.rows);
})  

app.get('/sellerProfile/:info', async (req, res) => {
  const info = req.params.info;
  const parts = info.split('_');

  const data = await runQuery(
        `SELECT S.NAME, S.EMAIL, S.CONTACT, L.DISTRICT, L.THANA, L.AREA, L.DETAILS 
        FROM SELLER S JOIN SELLER_LOCATION L ON (S.LOCATION_ID=L.LOCATION_ID) 
        WHERE S.EMAIL=:EMAIL AND S.PASSWORD=:PASSWORD`, {
            EMAIL: parts[0],
            PASSWORD: parts[1]
        }
    );
  res.send(data.rows);
})  



app.get('/product/allcommercialplant', async (req, res) => {
  
  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME, P.AVAILABLE_QUANTITY, C.PRICE
        FROM PRODUCT P JOIN COMMERCIAL C ON (P.PRODUCT_ID=C.PRODUCT_ID)
        WHERE P.CATEGORY='plant'`
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 


app.get('/product/allgiftplant', async (req, res) => {
  
  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME, P.AVAILABLE_QUANTITY
        FROM PRODUCT P JOIN GIFT G ON (P.PRODUCT_ID=G.PRODUCT_ID)
        WHERE P.CATEGORY='plant'`
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 


app.get('/searchgiftplant/:word', async (req, res) => {
  const info = req.params.word;
  const parts = info.split(' ');

  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME ,P.AVAILABLE_QUANTITY
        FROM PRODUCT P JOIN GIFT G
        ON P.PRODUCT_ID = G.PRODUCT_ID
        WHERE P.CATEGORY = 'plant' AND INSTR(UPPER(P.PRODUCT_NAME),UPPER(:key))>0`,{
          key:parts[0]
        }
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 


app.get('/searchcommercialplant/:word', async (req, res) => {
  const info = req.params.word;
  const parts = info.split(' ');

  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME, P.AVAILABLE_QUANTITY, C.PRICE
        FROM PRODUCT P JOIN COMMERCIAL C
        ON P.PRODUCT_ID = C.PRODUCT_ID
        WHERE P.CATEGORY ='plant' AND INSTR(UPPER(P.PRODUCT_NAME),UPPER(:key))>0`,{
          key:parts[0]
        }
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 


app.get('/product/allcommercialseed', async (req, res) => {
  
  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME, P.AVAILABLE_QUANTITY, C.PRICE
        FROM PRODUCT P JOIN COMMERCIAL C ON (P.PRODUCT_ID=C.PRODUCT_ID)
        WHERE P.CATEGORY='seed'`
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 

app.get('/searchcommercialseed/:word', async (req, res) => {
  const info = req.params.word;
  const parts = info.split(' ');

  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME, P.AVAILABLE_QUANTITY, C.PRICE
        FROM PRODUCT P JOIN COMMERCIAL C
        ON P.PRODUCT_ID = C.PRODUCT_ID
        WHERE P.CATEGORY ='seed' AND INSTR(UPPER(P.PRODUCT_NAME),UPPER(:key))>0`,{
          key:parts[0]
        }
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 

app.get('/product/allgiftseed', async (req, res) => {
  
  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME, P.AVAILABLE_QUANTITY
        FROM PRODUCT P JOIN GIFT G ON (P.PRODUCT_ID=G.PRODUCT_ID)
        WHERE P.CATEGORY='seed'`
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 


app.get('/searchgiftseed/:word', async (req, res) => {
  const info = req.params.word;
  const parts = info.split(' ');

  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME ,P.AVAILABLE_QUANTITY
        FROM PRODUCT P JOIN GIFT G
        ON P.PRODUCT_ID = G.PRODUCT_ID
        WHERE P.CATEGORY = 'seed' AND INSTR(UPPER(P.PRODUCT_NAME),UPPER(:key))>0`,{
          key:parts[0]
        }
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 


app.get('/product/allcommercialaccessories', async (req, res) => {
  
  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME, P.AVAILABLE_QUANTITY, C.PRICE
        FROM PRODUCT P JOIN COMMERCIAL C ON (P.PRODUCT_ID=C.PRODUCT_ID)
        WHERE P.CATEGORY='accessories'`
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 

app.get('/searchcommercialaccessories/:word', async (req, res) => {
  const info = req.params.word;
  const parts = info.split(' ');

  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME, P.AVAILABLE_QUANTITY, C.PRICE
        FROM PRODUCT P JOIN COMMERCIAL C
        ON P.PRODUCT_ID = C.PRODUCT_ID
        WHERE P.CATEGORY ='accessories' AND INSTR(UPPER(P.PRODUCT_NAME),UPPER(:key))>0`,{
          key:parts[0]
        }
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 

app.get('/product/allgiftaccessories', async (req, res) => {
  
  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME, P.AVAILABLE_QUANTITY
        FROM PRODUCT P JOIN GIFT G ON (P.PRODUCT_ID=G.PRODUCT_ID)
        WHERE P.CATEGORY='accessories'`
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 


app.get('/searchgiftaccessories/:word', async (req, res) => {
  const info = req.params.word;
  const parts = info.split(' ');

  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME ,P.AVAILABLE_QUANTITY
        FROM PRODUCT P JOIN GIFT G
        ON P.PRODUCT_ID = G.PRODUCT_ID
        WHERE P.CATEGORY = 'accessories' AND INSTR(UPPER(P.PRODUCT_NAME),UPPER(:key))>0`,{
          key:parts[0]
        }
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 


app.get('/addproducttowishlist/:info', async (req, res) => {
  const info = req.params.info;
  const parts = info.split('_');

  const data = await runQuery(
    `DECLARE
    CNFRM VARCHAR2(50);
    BEGIN
    CNFRM:=WISHADD(:EMAIL, :PASSWORD, :PROID);
    END;`,{
      EMAIL:parts[0],
      PASSWORD:parts[1],
      PROID: parts[2]
    }
    );
  //console.log(data);
  res.send(data);
}) 


app.get('/sellerId/:info', async (req, res) => {
  const info = req.params.info;
  const parts = info.split('_');

  const data = await runQuery(
        `SELECT SELLER_ID 
        FROM SELLER
        WHERE EMAIL=:EMAIL AND PASSWORD=:PASSWORD`, {
            EMAIL: parts[0],
            PASSWORD: parts[1]
        }
    );
  res.send(data.rows);
}) 


app.get('/mycommercialproducts/:info', async (req, res) => {
  const info = req.params.info;
  //const parts = info.split('_');

  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME, M.PRICE, P.AVAILABLE_QUANTITY
        FROM COMMERCIAL_OWNER C JOIN PRODUCT P ON (C.PRODUCT_ID=P.PRODUCT_ID) JOIN COMMERCIAL M ON (P.PRODUCT_ID=M.PRODUCT_ID)
        WHERE C.SELLER_ID=:SELLER_ID`, {
            SELLER_ID:info
        }
    );
  res.send(data.rows);
}) 


app.get('/mygiftproducts/:info', async (req, res) => {
  const info = req.params.info;
  //const parts = info.split('_');

  const data = await runQuery(
        `SELECT P.PRODUCT_ID, P.PRODUCT_NAME, P.AVAILABLE_QUANTITY
        FROM GIFT_OWNER GO JOIN PRODUCT P ON (GO.PRODUCT_ID=P.PRODUCT_ID)
        WHERE GO.SELLER_ID=:SELLER_ID`, {
            SELLER_ID:info
        }
    );
  res.send(data.rows);
}) 

//account delete


app.get('/buyeraccountdelete/:info', async (req, res) => {  //email_pass
  const info = req.params.info;
  const parts = info.split('_');

  const data = await runQuery(
        `DECLARE
        BYRID INTEGER;
        BEGIN
        SELECT BUYER_ID INTO BYRID FROM BUYER WHERE EMAIL=:EMAIL AND PASSWORD=:PASSWORD;
        DELETE FROM BUYER WHERE BUYER_ID=BYRID;
        COMMIT;
        END ;`, {
            EMAIL:parts[0],
            PASSWORD:parts[1]
        }
    );
  res.send(data);
}) 


app.get('/selleraccountdelete/:info', async (req, res) => {  //email_pass
  const info = req.params.info;
  const parts = info.split('_');

  const data = await runQuery(
        `DECLARE
        SLID INTEGER;
        BEGIN
        SELECT SELLER_ID INTO SLID FROM SELLER WHERE EMAIL = :EMAIL AND PASSWORD = :PASSWORD;
        FOR R IN (
        SELECT PRODUCT_ID FROM COMMERCIAL_OWNER
        WHERE SELLER_ID = SLID
        UNION 
        SELECT PRODUCT_ID FROM GIFT_OWNER
        WHERE SELLER_ID = SLID
         )
        LOOP
        DELETE FROM PRODUCT WHERE PRODUCT_ID = R.PRODUCT_ID;
        COMMIT;
        END LOOP;
        DELETE FROM SELLER WHERE SELLER_ID = SLID;
        COMMIT;
        END;`, {
            EMAIL:parts[0],
            PASSWORD:parts[1]
        }
    );
  res.send(data);
}) 


// reset password


app.get('/buyerpasswordreset/:info', async (req, res) => {  //email_currentpass_newpass
  const info = req.params.info;
  const parts = info.split('_');

  const data = await runQuery(
        `DECLARE
        BYRD INTEGER;
        BEGIN
        SELECT BUYER_ID INTO BYRD FROM BUYER WHERE EMAIL=:EMAIL AND PASSWORD=:PASSWORD;
        UPDATE BUYER SET PASSWORD=:NEWPASS WHERE BUYER_ID=BYRD;
        COMMIT;
        END ;`, {
            EMAIL:parts[0],
            PASSWORD:parts[1],
            NEWPASS:parts[2]
        }
    );
  res.send(data);
}) 

app.get('/sellerpasswordreset/:info', async (req, res) => {  //email_currentpass_newpass
  const info = req.params.info;
  const parts = info.split('_');

  const data = await runQuery(
        `DECLARE
        SLRD INTEGER;
        BEGIN
        SELECT SELLER_ID INTO SLRD FROM SELLER WHERE EMAIL=:EMAIL AND PASSWORD=:PASSWORD;
        UPDATE SELLER SET PASSWORD=:NEWPASS WHERE SELLER_ID=SLRD;
        COMMIT;
        END ;`, {
            EMAIL:parts[0],
            PASSWORD:parts[1],
            NEWPASS:parts[2]
        }
    );
  res.send(data);
}) 


///  product decrease

app.get('/decrease/:info', async (req, res) => {  //product id
  const info = req.params.info;

  const data = await runQuery(
        `DECLARE
        BEGIN
        DECREASE(:ID);
        END;`, {
            ID:info
        }
    );
  res.send(data);
}) 

// product increase

app.get('/increase/:info', async (req, res) => {  //product id
  const info = req.params.info;

  const data = await runQuery(
        `DECLARE
        BEGIN
        INCREASE(:ID);
        END;`, {
            ID:info
        }
    );
  res.send(data);
})


// product remove

app.get('/remove/:info', async (req, res) => {  //product id
  const info = req.params.info;

  const data = await runQuery(
        `DECLARE
        BEGIN
        REMOVE(:ID);
        END;`, {
            ID:info
        }
    );
  res.send(data);
})




/// launch commercial product

app.get('/launchcommercial/:info', async (req, res) => {  //seller id_pro name_av qntt_cat_pr
  const info = req.params.info;
  const parts = info.split('_');

  const data = await runQuery(
        `DECLARE
        CID NUMBER;
        BEGIN
        SELECT MAX(PRODUCT_ID) INTO CID FROM PRODUCT;
        CID := CID + 1;
        INSERT INTO PRODUCT (PRODUCT_ID, PRODUCT_NAME, AVAILABLE_QUANTITY, CATEGORY) VALUES (CID, :PN, :AQ, :CAT);
        COMMIT;
        INSERT INTO COMMERCIAL (PRODUCT_ID, PRICE) VALUES (CID, :PR);
        COMMIT;
        INSERT INTO COMMERCIAL_OWNER (SELLER_ID, PRODUCT_ID) VALUES (:SI, CID);
        COMMIT;
        END;`, {
            SI:parts[0],
            PN:parts[1],
            AQ:parts[2],
            CAT:parts[3],
            PR:parts[4]
        }
    );
  res.send(data);
}) 

// launch gift product

app.get('/launchgift/:info', async (req, res) => {  //seller id_pro name_av qntt_cat
  const info = req.params.info;
  const parts = info.split('_');

  const data = await runQuery(
        `DECLARE
        GID NUMBER;
        BEGIN
        SELECT MAX(PRODUCT_ID) INTO GID FROM PRODUCT;
        GID := GID + 1;
        INSERT INTO PRODUCT (PRODUCT_ID, PRODUCT_NAME, AVAILABLE_QUANTITY, CATEGORY) VALUES (GID, :PN, :AQ, :CAT);
        COMMIT;
        INSERT INTO GIFT (PRODUCT_ID) VALUES (GID);
        COMMIT;
        INSERT INTO GIFT_OWNER (SELLER_ID, PRODUCT_ID) VALUES (:SI, GID);
        COMMIT;
        END;`, {
            SI:parts[0],
            PN:parts[1],
            AQ:parts[2],
            CAT:parts[3]
        }
    );
  res.send(data);
}) 


/// my wishlist of buyer

app.get('/mywishlist/:info', async (req, res) => {  //email_pass
  const info = req.params.info;
  const parts = info.split('_');

  const data = await runQuery(
        `SELECT P.PRODUCT_ID,P.PRODUCT_NAME, COUNT(*) AS QUANTITY, PW.PRICE_PER_PIECE*COUNT(*) AS PRICE
        FROM PRODUCT P JOIN PRODUCT_IN_WISHLIST PW ON (P.PRODUCT_ID = PW.PRODUCT_ID)
        WHERE PW.BUYER_ID IN (
            SELECT B.BUYER_ID
            FROM BUYER B
            WHERE EMAIL = :EMAIL AND PASSWORD = :PASSWORD
        )
        GROUP BY P.PRODUCT_ID,P.PRODUCT_NAME,PW.PRICE_PER_PIECE`, {
          EMAIL:parts[0],
          PASSWORD:parts[1]
        }
    );
  res.send(data.rows);
}) 


// remove from wishlist, given: buyer email, pass, pro id

app.get('/removefromwishlist/:info', async (req, res) => {  //email_pass_pro id
  const info = req.params.info;
  const parts = info.split('_');

  const data = await runQuery(
        `DECLARE
        B_ID INTEGER;
        BEGIN
        SELECT BUYER_ID INTO B_ID
        FROM BUYER 
        WHERE EMAIL = :EMAIL AND PASSWORD = :PASSWORD;
        
        FOR R IN (SELECT PRODUCT_ID FROM PRODUCT_IN_WISHLIST WHERE BUYER_ID = B_ID AND PRODUCT_ID=:PRODUCTID) 
        LOOP
        DELETE FROM PRODUCT_IN_WISHLIST WHERE PRODUCT_ID = R.PRODUCT_ID;
        COMMIT;
        END LOOP;
        END;`, {
          EMAIL:parts[0],
          PASSWORD:parts[1],
          PRODUCTID:parts[2]
        }
    );
  res.send(data.rows);
}) 


// show details

app.get('/details/:info', async (req, res) => {  //pro id
  const info = req.params.info;
 // const parts = info.split('_');

  const data = await runQuery(
        `SELECT P.PRODUCT_NAME, S.NAME, S.EMAIL, S.CONTACT, SL.DISTRICT, SL.THANA, SL.AREA, SL.DETAILS
        FROM PRODUCT P JOIN COMMERCIAL_OWNER CW ON (CW.PRODUCT_ID = P.PRODUCT_ID)
        JOIN SELLER S ON (S.SELLER_ID = CW.SELLER_ID)
        JOIN SELLER_LOCATION SL ON (S.LOCATION_ID = SL.LOCATION_ID)
        WHERE P.PRODUCT_ID =:PID
        UNION
        (
        SELECT P.PRODUCT_NAME, S.NAME, S.EMAIL, S.CONTACT, SL.DISTRICT, SL.THANA, SL.AREA, SL.DETAILS
        FROM PRODUCT P JOIN GIFT_OWNER GW ON (GW.PRODUCT_ID = P.PRODUCT_ID)
        JOIN SELLER S ON (S.SELLER_ID = GW.SELLER_ID)
        JOIN SELLER_LOCATION SL ON (S.LOCATION_ID = SL.LOCATION_ID)
        WHERE P.PRODUCT_ID = :PID
        )`, {
          PID:info
        }
    );
  //console.log(data.rows);
  res.send(data.rows);
}) 