const email=document.getElementById('email');
const password=document.getElementById('password');
//const confirmText=document.getElementById('text');

async function sellerSignIn(event){
  event.preventDefault();
  const em=email.value;
  const pass=password.value;
  
  const response= await fetch(`/sellerSignIn/${em}`);
  const data = await response.json();
  //console.log(id);
  //console.log(data);

  if(`${data[0][3]}`==`${pass}`){
    // Redirect to the desired HTML file
    //console.log("matched");
    //window.location.href = "sellerProfile.html";
    localStorage.setItem('sellerEmail',em);
    localStorage.setItem('sellerPassword',pass);
    
    location.replace('http://localhost:4000/sellerProfile.html');
    // confirmText.textContent=`Login successful!`;
    // console.log(confirmText);
  }
  else{
    alert('Invalid email or password');
  }
}
