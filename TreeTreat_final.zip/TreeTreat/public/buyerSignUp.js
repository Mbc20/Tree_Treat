const nm=document.getElementById('name');
const email=document.getElementById('email');
const password=document.getElementById('password');
const contact=document.getElementById('contact');
//const confirmText=document.getElementById('text');

async function buyerSignUp(){

  if(password.value.includes("_")){
    alert('underscore is not allowed as password');
  }

  else if (nm.value.trim() === '' || email.value.trim() === '' || password.value === '' || contact.value.trim() === '') {
    alert('Please fill out all required fields.');
    //return false; // Prevent form submission
}

  else{
    const n=nm.value;
    const em=email.value;
    const pass=password.value;
    const cont=contact.value;

    const str=`${n}_${em}_${pass}_${cont}`;

    const response= await fetch(`/buyerSignUp/${str}`);
    location.replace('http://localhost:4000/signIn.html');
  }
  
}
