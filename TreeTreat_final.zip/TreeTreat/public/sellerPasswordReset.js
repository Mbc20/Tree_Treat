const currentpassword=document.getElementById('current-password');
const newpassword=document.getElementById('new-password');

async function sellerPasswordReset(event){
  event.preventDefault();
  
  const cp= currentpassword.value;
  const np=newpassword.value;

  const str=`${localStorage.getItem('sellerEmail')}_${localStorage.getItem('sellerPassword')}_${np}`;

  if(`${cp}`==`${localStorage.getItem('sellerPassword')}`){
    const response= await fetch(`/sellerpasswordreset/${str}`);
    
    location.replace('http://localhost:4000/signIn.html');
  }
  else{
    alert('Wrong current password');
  }
}













const password=document.getElementById('password');

async function buyerAccountDelete(event){
  event.preventDefault();
  
  const pass=password.value;

  const str=`${localStorage.getItem('buyerEmail')}_${pass}`;

  console.log(str);

  if(`${localStorage.getItem('buyerPassword')}`==`${pass}`){
    
    const response= await fetch(`/buyeraccountdelete/${str}`);
    //const data = await response.json();
    
    location.replace('http://localhost:4000/index.html');
  }

  else{
    alert('Invalid password');
  }
  
}
