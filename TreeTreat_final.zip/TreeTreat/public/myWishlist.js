const productList= document.getElementById('product-list');

async function remove(id){
  
  const str=`${localStorage.getItem('buyerEmail')}_${localStorage.getItem('buyerPassword')}_${id}`;

  const data = await fetch(`/removefromwishlist/${str}`);
  alert('Product removed. Please refresh to see the upadated wishlist.');
}

async function details(id,event){
  event.preventDefault();
  
  // const str=`${localStorage.getItem('buyerEmail')}_${localStorage.getItem('buyerPassword')}_${id}`;

  

  localStorage.setItem('pid',`${id}`);

  // localStorage.setItem('dtimg',`images/${id}.png`);
  // localStorage.setItem('dtpname',`${data[0][0]}`);
  // localStorage.setItem('dtsname',`${data[0][1]}`);
  // localStorage.setItem('dtsemail',`${data[0][2]}`);
  // localStorage.setItem('dtscontact',`${data[0][3]}`);
  // localStorage.setItem('dtsdist',`${data[0][4]}`);
  // localStorage.setItem('dtsthana',`${data[0][5]}`);
  // localStorage.setItem('dtsarea',`${data[0][6]}`);
  // localStorage.setItem('dtsdetails',`${data[0][7]}`);

  console.log('done');

  // alert('Product removed. Please refresh to see the upadated wishlist.');
  location.replace('http://localhost:4000/description.html');
}

async function wishlistBox(){

  console.log("here");
  const str=`${localStorage.getItem('buyerEmail')}_${localStorage.getItem('buyerPassword')}`;

  const response = await fetch(`/mywishlist/${str}`);
  const dataArray = await response.json();

  productList.innerHTML='';

  for(const data of dataArray) {
    const productBox = document.createElement("div");
    productBox.className="product-box";

    const im=`images/${data[0]}.png`;
    //const tp=data[2]*data[3];

    productBox.innerHTML=`
    
    <img src="${im}" alt="Product Image" class="product-image" onClick="details('${data[0]}',event)"></img>
    
    <div class="product-field"><span>Name:</span><div class="output-field">${data[1]}</div></div>

    <div class="product-field"><span>Quantity:</span><div class="output-field">${data[2]}</div></div>

    <div class="product-field"><span>Price:</span>
    <div class="output-field">${data[3]}</div></div>
    <div></div>
    
    <div class="product-field">
    <button class="remove-button" onClick="remove('${data[0]}')">Remove</button>
    </div>
    `;

    productList.appendChild(productBox);
  }
}




window.onload = function() {
  wishlistBox();
};


