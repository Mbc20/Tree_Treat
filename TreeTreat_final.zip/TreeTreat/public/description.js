
const sname=document.getElementById('name');
const semail=document.getElementById('email');
const scontact=document.getElementById('contact');
const sdistrict=document.getElementById('district');
const sthana=document.getElementById('thana');
const sarea=document.getElementById('area');
const sdetails=document.getElementById('details');

async function showDetails(){

  console.log(`${localStorage.getItem('pid')}`);
  const response = await fetch(`/details/${localStorage.getItem('pid')}`);

  const data= await response.json();

  console.log(data);

  
  sname.textContent=`${data[0][1]}`;
  semail.textContent=`${data[0][2]}`;
  scontact.textContent=`${data[0][3]}`;
  sdistrict.textContent=`${data[0][4]}`;
  sthana.textContent=`${data[0][5]}`;
  sarea.textContent=`${data[0][6]}`;
  sdetails.textContent=`${data[0][7]}`;

  
}


window.onload = function() {
  showDetails();
};