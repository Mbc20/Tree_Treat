const nam=document.getElementById('name');
const quantit=document.getElementById('quantity');
const categor=document.getElementById('category');
const pric=document.getElementById('price');


async function launchCommercial(event){
  event.preventDefault();

  const str1=`${localStorage.getItem('sellerEmail')}_${localStorage.getItem('sellerPassword')}`;

  console.log(str1);

  const data1 = await fetch(`/sellerId/${str1}`); // seller id
  const data2=await data1.json();

  console.log(data2);

  const str2=`${data2[0][0]}_${nam.value}_${quantit.value}_${categor.value}_${pric.value}`;

  const response = await fetch(`/launchcommercial/${str2}`);

  location.replace('http://localhost:4000/sellerProfile.html');

}