
const productList= document.getElementById('product-list');

async function decrease(id){
  //const Id=id.value;
  const data = await fetch(`/decrease/${id}`);
  alert('Quantity updated. Please refresh to see the upadated list.');
}

async function increase(id){
  //const Id=id.value;
  const data = await fetch(`/increase/${id}`);
  alert('Quantity updated. Please refresh to see the upadated list.');
}

async function remove(id){
  //const Id=id.value;
  const data = await fetch(`/remove/${id}`);
  alert('Product removed. Please refresh to see the upadated list.');
}

async function createMyCommercialProductBoxes(){
  
  const str1=`${localStorage.getItem('sellerEmail')}_${localStorage.getItem('sellerPassword')}`;

  console.log(str1);

  const data1 = await fetch(`/sellerId/${str1}`); // seller id
  const data2=await data1.json();

  console.log(data2);

  const response = await fetch(`/mycommercialproducts/${data2[0][0]}`); //commercial owner table theke seller id diye query kore niye asbe.

  const dataArray = await response.json();

  productList.innerHTML='';

  for(const data of dataArray) {
    const productBox = document.createElement("div");
    productBox.className="product-box";

    const im=`images/${data[0]}.png`;

    productBox.innerHTML=`
    
    <img src="${im}" alt="Product Image" class="product-image"></img>
    
    <div class="product-field"><span>Name:</span><div class="output-field">${data[1]}</div></div>

    <div class="product-field"><span>Price:</span>
    <div class="output-field">${data[2]}</div></div>

    <div class="product-field"><span>Quantity:</span><div class="output-field">${data[3]}</div></div>

    <div class="product-field">
    <button class="quantity-button" onClick="increase('${data[0]}')">+</button>
    <button class="quantity-button" onClick="decrease('${data[0]}')">-</button>
    </div>

    <div class="product-field">
    <button class="remove-button" onClick="remove('${data[0]}')">Remove</button>
    </div>
    `;

    productList.appendChild(productBox);
  }
}







async function createMyGiftProductBoxes(){
  
  const str1=`${localStorage.getItem('sellerEmail')}_${localStorage.getItem('sellerPassword')}`;

  console.log(str1);

  const data1 = await fetch(`/sellerId/${str1}`); // seller id
  const data2=await data1.json();

  console.log(data2);

  const response = await fetch(`/mygiftproducts/${data2[0][0]}`); //gift owner table theke seller id diye query kore niye asbe.

  const dataArray = await response.json();

  productList.innerHTML='';

  for(const data of dataArray) {
    const productBox = document.createElement("div");
    productBox.className="product-box";

    const im=`images/${data[0]}.png`;

    productBox.innerHTML=`
    
    <img src="${im}" alt="Product Image" class="product-image"></img>
    
    <div class="product-field"><span>Name:</span><div class="output-field">${data[1]}</div></div>

    <div class="product-field"><span>&#x1F381;</span>
    </div>

    <div class="product-field"><span>Quantity:</span><div class="output-field">${data[2]}</div></div>

    <div class="product-field">
    <button class="quantity-button" onClick="increase('${data[0]}')">+</button>
    <button class="quantity-button" onClick="decrease('${data[0]}')">-</button>
    </div>

    <div class="product-field">
    <button class="remove-button" onClick="remove('${data[0]}')">Remove</button>
    </div>
    `;

    productList.appendChild(productBox);
  }
}






