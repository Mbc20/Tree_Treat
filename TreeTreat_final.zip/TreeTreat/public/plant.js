
const productContainer = document.getElementById("product-container");
const srch = document.getElementById('search');

async function addProductToWishlist(id){
    //const Id= id.value;
    const str=`${localStorage.getItem('buyerEmail')}_${localStorage.getItem('buyerPassword')}_${id}`;
  
    const response = await fetch(`/addproducttowishlist/${str}`);
    //const data = await response.json();
    alert('product added');
  }


// Function to create and append product boxes

async function createCommercialPlantBoxes() {  // when click 'commercial' button
    
    //console.log('here');
    const response = await fetch('/product/allcommercialplant');
    const dataArray = await response.json();
    //console.log(dataArray);

    
    productContainer.innerHTML = '';

    for (const data of dataArray) {
        const productBox = document.createElement("div");
        productBox.className = "product-box";

        const im=`images/${data[0]}.png`;

        productBox.innerHTML = `
            <img src="${im}" alt="Product Image" class="product-image"></img>
            
            <div class="product-field">
                <span>Name:</span>
                <div class="output-field">${data[1]}</div>
            </div>
            <div class="product-field">
                <span>Price:</span>
                <div class="output-field">${data[3]} tk</div>
            </div>
            
            <div class="product-field">
                <span>Available Quantity:</span>
                <div class="output-field">${data[2]}</div>
            </div>
            <div><br></div>
            <div class="product-field">
                <button class="cart-button" onClick="addProductToWishlist('${data[0]}')">Add to Wishlist</button>
            </div>
            
        `;

        productContainer.appendChild(productBox);
    }
}

async function searchCommercialPlant() {
    
    const search=srch.value;
    
    const response = await fetch(`/searchcommercialplant/${search}`);
    const dataArray = await response.json();
    
    productContainer.innerHTML = '';

    for (const data of dataArray) {
        const productBox = document.createElement("div");
        productBox.className = "product-box";

        const im=`images/${data[0]}.png`;

        productBox.innerHTML = `
            <img src="${im}" alt="Product Image" class="product-image"></img>
            
            <div class="product-field">
                <span>Name:</span>
                <div class="output-field">${data[1]}</div>
            </div>
            <div class="product-field">
                <span>Price:</span>
                <div class="output-field">${data[3]} tk</div>
            </div>
            
            <div class="product-field">
                <span>Available Quantity:</span>
                <div class="output-field">${data[2]}</div>
            </div>
            <div><br></div>
            <div class="product-field">
                <button class="cart-button" onClick="addProductToWishlist('${data[0]}')">Add to Wishlist</button>
            </div>
        `;

        productContainer.appendChild(productBox);
    }
}

async function createGiftPlantBoxes() {
    //console.log('here');
    const response = await fetch('/product/allgiftplant');
    const dataArray = await response.json();
    
    productContainer.innerHTML = '';

    for (const data of dataArray) {
        const productBox = document.createElement("div");
        productBox.className = "product-box";

        const im=`images/${data[0]}.png`;

        productBox.innerHTML = `
            <img src="${im}" alt="Product Image" class="product-image"></img>
            <div class="product-field">
                <span>Name:</span>
                <div class="output-field">${data[1]}</div>
            </div>
            <div class="product-field">
                <span>Available Quantity:</span>
                <div class="output-field">${data[2]}</div>
            </div>

            <div><span><h3>Gift &#x1F381;</h3></span></div>
            <div class="product-field">
                <button class="cart-button" onClick="addProductToWishlist('${data[0]}')">Add to Wishlist</button>
            </div>
        `;

        productContainer.appendChild(productBox);
    }
}


async function searchGiftPlant() {
    //console.log('here');
    //console.log(srch);
    const search= srch.value;

    const response = await fetch(`/searchgiftplant/${search}`);
    const dataArray = await response.json();
    
    productContainer.innerHTML = '';

    for (const data of dataArray) {
        const productBox = document.createElement("div");
        productBox.className = "product-box";

        const im=`images/${data[0]}.png`;

        productBox.innerHTML = `
            <img src="${im}" alt="Product Image" class="product-image"></img>
            <div class="product-field">
                <span>Name:</span>
                <div class="output-field">${data[1]}</div>
            </div>
            <div class="product-field">
                <span>Available Quantity:</span>
                <div class="output-field">${data[2]}</div>
            </div>

            <div><span><h3>Gift &#x1F381;</h3></span></div>
            <div class="product-field">
                <button class="cart-button" onClick="addProductToWishlist('${data[0]}')">Add to Wishlist</button>
            </div>
        `;

        productContainer.appendChild(productBox);
    }
}


