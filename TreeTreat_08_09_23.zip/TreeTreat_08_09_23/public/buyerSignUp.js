const nm=document.getElementById('name');
const email=document.getElementById('email');
const password=document.getElementById('password');
const contact=document.getElementById('contact');
//const confirmText=document.getElementById('text');

async function buyerSignUp(){
  const n=nm.value;
  const em=email.value;
  const pass=password.value;
  const cont=contact.value;

  const str=`${n}_${em}_${pass}_${cont}`;

  const response= await fetch(`/buyerSignUp/${str}`);
  //const data = await response.json();
  //console.log(id);
  //console.log(data);

  //confirmText.textContent=`signup successful!`;

  // if(`${data[0][3]}`==`${pass}`){
  //   confirmText.textContent=`Login successful!`;
  // }
  // else{
  //   confirmText.textContent=`Wrong email/password :( Try again...`;
  // }
}
