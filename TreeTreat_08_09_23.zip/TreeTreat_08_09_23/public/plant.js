
const productContainer = document.getElementById("product-container");
// Function to create and append product boxes

async function createCommercialPlantBoxes() {
    //console.log('here');
    const response = await fetch('/product/allcommercialplant');
    const dataArray = await response.json();
    
    productContainer.innerHTML = '';

    for (const data of dataArray) {
        const productBox = document.createElement("div");
        productBox.className = "product-box";

        productBox.innerHTML = `
            <img src="sowing-sunflower.png" alt="Product Image" class="product-image"></img>
            <div class="product-field">
                <span>Name:</span>
                <div class="output-field">${data[0]}</div>
            </div>
            <div class="product-field">
                <span>Price:</span>
                <div class="output-field">${data[2]} tk</div>
            </div>
            
            <div class="product-field">
                <span>Available Quantity:</span>
                <div class="output-field">${data[1]}</div>
            </div>
            <div><br></div>
            <div class="product-field">
                <button class="cart-button">Add to Wishlist</button>
            </div>
        `;

        productContainer.appendChild(productBox);
    }
}


async function createGiftPlantBoxes() {
    //console.log('here');
    const response = await fetch('/product/allgiftplant');
    const dataArray = await response.json();
    
    productContainer.innerHTML = '';

    for (const data of dataArray) {
        const productBox = document.createElement("div");
        productBox.className = "product-box";

        productBox.innerHTML = `
            <img src="sowing-sunflower.png" alt="Product Image" class="product-image"></img>
            <div class="product-field">
                <span>Name:</span>
                <div class="output-field">${data[0]}</div>
            </div>
            <div class="product-field">
                <span>Available Quantity:</span>
                <div class="output-field">${data[1]}</div>
            </div>

            <div><span><h3>Gift &#x1F381;</h3></span></div>
            <div class="product-field">
                <button class="cart-button">Add to Wishlist</button>
            </div>
        `;

        productContainer.appendChild(productBox);
    }
}


// Call the function to create and append product boxes
//createProductBoxes();




{/* <div class="product-field">
                <span>Price:</span>
                <div class="output-field">${data.price}</div>
            </div> */}


            // <img src="${data.imageSrc}" alt="Product Image" class="product-image"></img>



            // function handleOptionChange() {
//     console.log('here');
//     const selectElement = document.getElementById("filter");
//     selectElement.addEventListener("change", handleOptionChange);

//     const selectedValue = selectElement.value;
    
//     // Check the selected option value and call the appropriate function
//     if (selectedValue === "all") {
//         console.log('in all');
//         // Call function for "All" option
//         createPlantBoxes();
//     } 
//     else if (selectedValue === "gift") {
//         // Call function for "Gift" option
//         handleGiftOption();
//     } 
//     else if (selectedValue === "commercial") {
//         // Call function for "Commercial" option
//         handleCommercialOption();
//     }
// }