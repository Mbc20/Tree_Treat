console.log(localStorage.getItem('sellerEmail'));
console.log(localStorage.getItem('sellerPassword'));