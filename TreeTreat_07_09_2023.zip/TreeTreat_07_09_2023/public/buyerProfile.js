//console.log(localStorage.getItem('buyerEmail'));
//const data = response.json();

const nam=document.getElementById('name');
const emai=document.getElementById('email');
const contac=document.getElementById('contact');

//console.log(data[0]);
// console.log(data);


async function buyerProfile(){

  const str=`${localStorage.getItem('buyerEmail')}_${localStorage.getItem('buyerPassword')}`;

  const response= await fetch(`/buyerProfile/${str}`);
  const data = await response.json();

  nam.textContent=`${data[0][1]}`;
  emai.textContent=`${data[0][2]}`;
  contac.textContent=`${data[0][4]}`;
}


window.onload = function() {
  buyerProfile();
};