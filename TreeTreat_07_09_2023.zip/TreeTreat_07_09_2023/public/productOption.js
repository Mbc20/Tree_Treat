const email=document.getElementById('email');
const password=document.getElementById('password');
const confirmText=document.getElementById('text');

async function profile(){
  const em=email.value;
  const pass=password.value;
  
  const response= await fetch(`/buyerSignIn/${em}`);
  const data = await response.json();
  //console.log(id);
  //console.log(data);

  if(`${data[0][3]}`==`${pass}`){
    // confirmText.textContent=`Login successful!`;
    // console.log(confirmText);
    window.location.href = "productOption.html";
  }
  else{
    alert('Invalid email or password');
  }
}
