
const productContainer = document.getElementById("product-container");
// Function to create and append product boxes

function handleOptionChange() {
    console.log('here');
    const selectElement = document.getElementById("filter");
    selectElement.addEventListener("change", handleOptionChange);

    const selectedValue = selectElement.value;
    
    // Check the selected option value and call the appropriate function
    if (selectedValue === "all") {
        console.log('in all');
        // Call function for "All" option
        createPlantBoxes();
    } 
    else if (selectedValue === "gift") {
        // Call function for "Gift" option
        handleGiftOption();
    } 
    else if (selectedValue === "commercial") {
        // Call function for "Commercial" option
        handleCommercialOption();
    }
}



async function createPlantBoxes() {
    console.log('here');
    const response = await fetch('/product/allplant');
    const dataArray = await response.json();
    
    productContainer.innerHTML = '';

    for (const data of dataArray) {
        const productBox = document.createElement("div");
        productBox.className = "product-box";

        //const product = productDataArray[i % productDataArray.length]; // Reuse product data in a loop

        productBox.innerHTML = `
            
            <div class="product-field">
                <span>ID:</span>
                <div class="output-field">${data[0]}</div>
            </div>
            <div class="product-field">
                <span>Name:</span>
                <div class="output-field">${data[1]}</div>
            </div>
            
            <div class="product-field">
                <span>Quantity:</span>
                <div class="output-field">${data[2]}</div>
            </div>
            <div class="product-field">
                <button class="cart-button">Add to Wishlist</button>
            </div>
        `;

        productContainer.appendChild(productBox);
    }
}


// Call the function to create and append product boxes
//createProductBoxes();




{/* <div class="product-field">
                <span>Price:</span>
                <div class="output-field">${data.price}</div>
            </div> */}


            // <img src="${data.imageSrc}" alt="Product Image" class="product-image"></img>