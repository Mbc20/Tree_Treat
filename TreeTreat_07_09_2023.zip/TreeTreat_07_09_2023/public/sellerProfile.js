const nam=document.getElementById('name');
const emai=document.getElementById('email');
const contac=document.getElementById('contact');
const distric=document.getElementById('district');
const than=document.getElementById('thana');
const are=document.getElementById('area');
const detail=document.getElementById('details');


async function buyerProfile(){

  const str=`${localStorage.getItem('sellerEmail')}_${localStorage.getItem('sellerPassword')}`;

  const response= await fetch(`/buyerProfile/${str}`);
  const data = await response.json();

  nam.textContent=`${data[0][1]}`;
  emai.textContent=`${data[0][2]}`;
  contac.textContent=`${data[0][4]}`;
  distric.textContent=`${data[0][4]}`;
  than.textContent=`${data[0][4]}`;
  are.textContent=`${data[0][4]}`;
  detail.textContent=`${data[0][4]}`;
}


window.onload = function() {
  buyerProfile();
};